package com.ideabobo.service;

import com.ideabobo.model.Kakou;

public interface KakouMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Kakou record);

    int insertSelective(Kakou record);

    Kakou selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Kakou record);

    int updateByPrimaryKey(Kakou record);
}